﻿
'-Begin-----------------------------------------------------------------

Public Module SAPGUIScripting

  Sub Main()

    Dim SapGuiAuto As Object
    Dim app As Object
    Dim connection As Object
    Dim session As Object

    Try
      SapGuiAuto = GetObject("SAPGUI")
      app = SapGuiAuto.GetScriptingEngine
      app.HistoryEnabled = False
      connection = app.Children(0)
      If connection.DisabledByServer = True Then
        Exit Sub
      End If
      session = connection.Children(0)
      If session.Busy = True Then
        Exit Sub
      End If
      If session.Info.IsLowSpeedConnection = True Then
        Exit Sub
      End If
    Catch
      Exit Sub
    End Try

session.findById("wnd[0]").maximize
session.findById("wnd[0]/usr/subSUB0:SAPLMEGUI:0019/subSUB3:SAPLMEVIEWS:1100/subSUB2:SAPLMEVIEWS:1200/subSUB1:SAPLMEGUI:1301/subSUB2:SAPLMEGUI:1303/tabsITEM_DETAIL/tabpTABIDT13/ssubTABSTRIPCONTROL1SUB:SAPLMEVIEWS:1101/subSUB2:SAPLMEACCTVI:0100/subSUB1:SAPLMEACCTVI:1000/btnSORTDOWN").press


    app.HistoryEnabled = True

  End Sub

End Module

'-End-------------------------------------------------------------------
